CREATE TABLE [dbo].[silver_product_category_name_translation] (

	[product_category_name] varchar(8000) NULL, 
	[product_category_name_english] varchar(8000) NULL
);