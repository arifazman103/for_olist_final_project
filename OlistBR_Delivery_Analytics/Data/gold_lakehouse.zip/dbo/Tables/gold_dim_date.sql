CREATE TABLE [dbo].[gold_dim_date] (

	[full_date] date NULL, 
	[year] int NULL, 
	[month] int NULL, 
	[quarter] int NULL, 
	[day_of_week] int NULL, 
	[day_name] varchar(8000) NULL, 
	[month_name] varchar(8000) NULL, 
	[is_weekend] bit NULL, 
	[year_month] varchar(8000) NULL
);