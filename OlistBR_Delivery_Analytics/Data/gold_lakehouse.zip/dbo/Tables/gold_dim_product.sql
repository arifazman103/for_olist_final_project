CREATE TABLE [dbo].[gold_dim_product] (

	[product_id] varchar(8000) NULL, 
	[product_category_name] varchar(8000) NULL, 
	[product_category_name_english] varchar(8000) NULL, 
	[product_weight_g] int NULL, 
	[product_length_cm] int NULL, 
	[product_height_cm] int NULL, 
	[product_width_cm] int NULL, 
	[product_volume_cm3] int NULL, 
	[product_weight_kg] float NULL
);