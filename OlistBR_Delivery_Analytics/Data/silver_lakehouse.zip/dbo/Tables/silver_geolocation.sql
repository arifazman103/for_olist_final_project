CREATE TABLE [dbo].[silver_geolocation] (

	[geolocation_zip_code_prefix] int NULL, 
	[geolocation_lat] float NULL, 
	[geolocation_lng] float NULL, 
	[geolocation_city] varchar(8000) NULL, 
	[geolocation_state] varchar(8000) NULL
);