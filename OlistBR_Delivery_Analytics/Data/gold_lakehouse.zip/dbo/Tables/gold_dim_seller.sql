CREATE TABLE [dbo].[gold_dim_seller] (

	[seller_id] varchar(8000) NULL, 
	[seller_zip_code_prefix] int NULL, 
	[seller_city] varchar(8000) NULL, 
	[seller_state] varchar(8000) NULL
);