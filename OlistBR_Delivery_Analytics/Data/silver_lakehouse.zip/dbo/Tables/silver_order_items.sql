CREATE TABLE [dbo].[silver_order_items] (

	[order_id] varchar(8000) NULL, 
	[order_item_id] int NULL, 
	[product_id] varchar(8000) NULL, 
	[seller_id] varchar(8000) NULL, 
	[shipping_limit_date] datetime2(6) NULL, 
	[price] float NULL, 
	[freight_value] float NULL
);