CREATE TABLE [dbo].[silver_products] (

	[product_id] varchar(8000) NULL, 
	[product_category_name] varchar(8000) NULL, 
	[product_name_length] int NULL, 
	[product_description_length] int NULL, 
	[product_photos_qty] int NULL, 
	[product_weight_g] int NULL, 
	[product_length_cm] int NULL, 
	[product_height_cm] int NULL, 
	[product_width_cm] int NULL
);